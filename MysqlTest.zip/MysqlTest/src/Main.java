
public class Main {
	public static void main(String[] args) throws Exception
	{
		MysqlHelper sqlHelper = new MysqlHelper("192.168.1.18", "3306", "mobiusdb", "root", "dbsckd");
		
		//sqlHelper.selectAll("lookup");
		//sqlHelper.selectAll("cin");
		sqlHelper.selectAll("lookup");
		//sqlHelper.selectAll("csr");
		//sqlHelper.selectAll("grp");
		//sqlHelper.selectColumn("lookup", "ct");
		//sqlHelper.select("lookup", "ty", "5");
	}
}
